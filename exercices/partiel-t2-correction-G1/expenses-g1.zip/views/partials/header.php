<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= $title ?></title>
	<link rel="stylesheet" href="<?= URL ?>src/css/foundation.min.css">
	<link rel="stylesheet" href="<?= URL ?>src/css/style.css">
</head>
<body class="page-<?= $class ?>">
	<header>
		<h1>Mon site</h1>
	</header>
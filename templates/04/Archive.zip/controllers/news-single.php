<?php

	$title = 'Article 1';
	$class = 'news-single';
<?php 

	$title = '404';
	$class = '404';
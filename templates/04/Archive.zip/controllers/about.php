<?php 

	$title = 'About';
	$class = 'about';
<?php 

	$title = 'News';
	$class = 'news';
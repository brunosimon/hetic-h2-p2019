<?php 

	$title = 'Mon site';
	$class = 'home';
<?php

define('URL','http://localhost/p2019/templates/04/');

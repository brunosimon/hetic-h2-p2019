	<footer>
		Footer
	</footer>
	<script src="<?= URL ?>src/js/libs/jquery-2.2.0.js"></script>
	<script src="<?= URL ?>src/js/app/script.js"></script>
</body>
</html>
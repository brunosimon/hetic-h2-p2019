<section>
	News Single
</section>
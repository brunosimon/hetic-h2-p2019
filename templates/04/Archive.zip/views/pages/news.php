<section>
	<a href="<?= URL ?>news/article-1">Article 1</a>
	<a href="<?= URL ?>news/article-2">Article 2</a>
	<a href="<?= URL ?>news/article-3">Article 3</a>
</section>
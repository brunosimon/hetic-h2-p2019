<?php

define('URL','http://localhost/p2019/exercices/partiel-t2-correction-G2/');

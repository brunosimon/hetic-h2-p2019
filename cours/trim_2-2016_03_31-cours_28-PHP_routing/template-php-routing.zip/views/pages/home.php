<?php 
	$title = 'Mon site';
?>
<section>
	Home
</section>
<?php 
	$title = 'Mon site';
?>
<section>
	News single
</section>
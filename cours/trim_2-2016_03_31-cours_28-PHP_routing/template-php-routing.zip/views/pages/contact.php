<?php 
	$title = 'Contact';
?>
<section>
	Contact
</section>
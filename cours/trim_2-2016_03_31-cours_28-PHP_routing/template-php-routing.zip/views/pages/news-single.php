<?php 
	$title = 'Ma news';
?>
<section>
	News single
</section>